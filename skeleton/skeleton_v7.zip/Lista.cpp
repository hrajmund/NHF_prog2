#include <iostream>
#include "Lista.h"

template <typename T>
Lista<T>::Lista(const T& value) : data(value), prev(nullptr), next(nullptr) {}

template <typename T>
T Lista<T>::getData() const {
	return data;
}

template <typename T>
Lista<T>* Lista<T>::getPrev() const {
	return prev;
}

template <typename T>
Lista<T>* Lista<T>::getNext() const {
	return next;
}

template <typename T>
void Lista<T>::setData(const T& value) {
	data = value;
}

template <typename T>
void Lista<T>::setPrev(Lista* pre) {
	prev = pre;
}

template <typename T>
void Lista<T>::setNext(Lista* nex) {
	next = nex;
}