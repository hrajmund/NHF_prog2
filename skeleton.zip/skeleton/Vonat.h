#pragma once
#ifndef VONAT_H
#define VONAT_H

#include "string5.h"
#include "Ido.h"
#include "Allomas.h"
#include "Kocsi.h"

class Vonat {
	String vonatNev;
	String vonatTipus;
	Kocsi* kocsik;

public:
	Vonat(const String& _vonatNev, const String& _vonatTipus, Kocsi* _kocsik):
		vonatNev(_vonatNev), 
		vonatTipus(_vonatTipus), 
		kocsik(_kocsik) {}

	String getVonatNev() const { return vonatNev; }
	String getVonatTipus() const { return vonatTipus; }
	Kocsi* getKocsik() const { return kocsik; }

	void setVonatNev(const String& nev) { vonatNev = nev; }
	void setVonatTipus(const String& tipus) { vonatTipus = tipus; }
	void setKocsik(Kocsi* kocsik) { this->kocsik = kocsik; }

	void kocsiAdd();
};

#endif