#ifndef KOCSI_H
#define KOCSI_H

#include <iostream>

class Kocsi {
	int sorSzam;
	int ferohely;
	bool kerekpar;
public:
	Kocsi() : sorSzam(0), ferohely(0), kerekpar(0) {}
	Kocsi(int _sorszam, int _ferohely, bool _kerekpar) : sorSzam(_sorszam), ferohely(_ferohely), kerekpar(_kerekpar) {}
	~Kocsi();
	
	int getSorSzam() { return sorSzam; }
	int getFerohely() { return ferohely; }
	bool getKerekpar() { return kerekpar; }

	void setSorSzam(int szam) { sorSzam = szam; }
	void setFerohely(int hely) { ferohely = hely; }
	void setKerekpar(bool vanKerekpar) { kerekpar = vanKerekpar; }

	void print(std::ostream& os) const;
};


#endif // !KOCSI_H
