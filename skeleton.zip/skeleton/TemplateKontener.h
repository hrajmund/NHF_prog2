#ifndef TEMPLATEKONTENER_H
#define TEMPLATEKONTENER_H

#include <iostream>

template <typename T>
class TemplateKontener {
private:
    struct Lista {
        T data;
        Lista* prev;
        Lista* next;

        Lista(const T& value) : data(value), prev(nullptr), next(nullptr) {}
    };

    Lista* head;
    Lista* tail;
    int size;

public:
    TemplateKontener() : head(nullptr), tail(nullptr), size(0) {}

    ~TemplateKontener() {
        clear();
    }

    void vegeBeszur(const T& value) {
        Lista* newLista = new Lista(value);

        if (isEmpty()) {
            head = tail = newLista;
        }
        else {
            tail->next = newLista;
            newLista->prev = tail;
            tail = newLista;
        }

        size++;
    }

    void elejeBeszur(const T& value) {
        Lista* newLista = new Lista(value);

        if (isEmpty()) {
            head = tail = newLista;
        }
        else {
            newLista->next = head;
            head->prev = newLista;
            head = newLista;
        }

        size++;
    }

    void kozepereBeszur(const T& value);

    void torlesVegerol() {
        if (isEmpty()) { return; }

        if (size == 1) {
            delete tail;
            head = tail = nullptr;
        }
        else {
            Lista* prevLista = tail->prev;
            prevLista->next = nullptr;
            delete tail;
            tail = prevLista;
        }

        size--;
    }

    void torlesElejerol() {
        if (isEmpty()) {
            return;
        }

        if (size == 1) {
            delete head;
            head = tail = nullptr;
        }
        else {
            Lista* nextLista = head->next;
            nextLista->prev = nullptr;
            delete head;
            head = nextLista;
        }

        size--;
    }

    void torlesParam(const T& value) {
        Lista* tmp = head;

        while (tmp) {
            if (tmp->data == value) {
                if (tmp == head) {
                    torlesElejerol();
                }
                else if (tmp == tail) {
                    torlesVegerol();
                }
                else {
                    tmp->prev->next = tmp->next;
                    tmp->next->prev = tmp->prev;
                    delete tmp;
                    size--;
                }

                return;
            }

            tmp = tmp->next;
        }
    }

    bool isEmpty() const { return size == 0; }

    int getSize() const { return size; }

    void clear() {
        Lista* current = head;

        while (current) {
            Lista* nextLista = current->next;
            delete current;
            current = nextLista;
        }

        head = tail = nullptr;
        size = 0;
    }
};

#endif // !TEMPLATEKONTENER_H
