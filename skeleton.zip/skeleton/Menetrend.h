#pragma once
#ifndef MENETREND_H
#define MENETREND_H

#include <iostream>
#include "Allomas.h"
#include "string5.h"

class Menetrend {
	Allomas* allomasok;
public:
	Menetrend() = default;
	Menetrend(Allomas* _allomasok) : allomasok(_allomasok) {}
	~Menetrend();

	void listazas(std::ostream& os) const;
	void allomasAdd();
	void allomasDel();
	Allomas& allomasKeres(String all);
};
#endif // !MENETREND_H
