#pragma once
#ifndef JEGY_H
#define JEGY_H

#include <iostream>
#include "string5.h"
#include "Ido.h"
#include "Vonat.h"
#include "Allomas.h"

class Jegy {
	String utasNev;
	Ido szulIdo;
	String kedvezEsEgyeb;
	Vonat train;
	Allomas indulas;
	Allomas erkezes;
	int ar = 0;
	int teljesTav = 0;
	String uloHely = "";
public:
	Jegy() = default;
	Jegy(String _nev, Ido _szulIdo, String _kedvez, Vonat _train, Allomas _indulas, Allomas _erkezes): 
		utasNev(_nev),
		szulIdo(_szulIdo), 
		kedvezEsEgyeb(_kedvez), 
		train(_train), 
		indulas(_indulas), 
		erkezes(_erkezes) {}
	~Jegy();

	String getUtasNev() const { return utasNev; }
	Ido getSzulIdo() const { return szulIdo; }
	String getKedvezEsEgyeb() const { return kedvezEsEgyeb; }
	Vonat getTrain() const { return train; }
	Allomas getIndulas() const { return indulas; }
	Allomas getErkezes() const { return erkezes; }
	int getAr() const { return ar; }
	int getTeljesTav() const { return teljesTav; }
	String getUloHely() const { return uloHely; }

	void setUtasNev(const String nev) { utasNev = nev; }
	void setSzulIdo(const Ido& ido) { szulIdo = ido; }
	void setKedvezEsEgyeb(const String& kedvez) { kedvezEsEgyeb = kedvez; }
	void setTrain(const Vonat& vonat) { train = vonat; }
	void setIndulas(const Allomas& allomas) { indulas = allomas; }
	void setErkezes(const Allomas& allomas) { erkezes = allomas; }

	void adatKiir(std::ostream& os) const;
	int teljesT(Allomas indulas, Allomas erkezes);
	int arKiszamolasa(String kedvez, int teljesTav);
	int uloHelyGen();
	void kesesKezeles();
};

#endif // !JEGY_H
