#pragma once
#ifndef ALLOMAS_H
#define ALLOMAS_H

#include <iostream>
#include "Ido.h"
#include "string5.h"
#include "Vonat.h"

class Allomas {
	String allomasNev;
	Vonat* vonatMegall;
	Ido idok;
public:
	Allomas(String _allomasNev, Vonat* _vonatMegall, Ido _idok) : allomasNev(_allomasNev), vonatMegall(_vonatMegall), idok(_idok) {}
	~Allomas();

	String getAllomasNev() const { return allomasNev; }
	Vonat* getVonatMegall() const { return vonatMegall; }
	Ido getIdok() const { return idok; }

	void setAllomasNev(const String& nev) { allomasNev = nev; }
	void setVonatMegall(Vonat* vonat) { vonatMegall = vonat; }
	void setIdok(const Ido& ido) { idok = ido; }
};
#endif // !ALLOMAS_H
