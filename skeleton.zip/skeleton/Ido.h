#pragma once
#ifndef IDO_H
#define IDO_H

#include <iostream>

class Ido {
private:
    int ev;
    int honap;
    int nap;
    int ora;
    int perc;
public:
    Ido(int y = 0, int m = 0, int d = 0, int h = 0, int min = 0) {
        ev = y;
        honap = m;
        nap = d;
        ora = h;
        perc = min;
    }

    Ido(int _ora, int _perc) : ora(_ora), perc(_perc) {};

    Ido(int _ev, int _honap, int _nap) : ev(_ev), honap(_honap), nap(_nap) {};

    void kiirTeljes() {
        std::cout << "Ev: " << ev << " Honap: " << honap << " Nap: " << nap << " Ora: " << ora << " Perc: " << perc << std::endl;
    }
    void kiirOraPerc() {
        std::cout << ora << ":" << perc << std::endl;
    }

    int getNapokAHonapban(int honap, int ev) const {
        if (honap == 2) {
            if (ev % 4 == 0 && (ev % 100 != 0 || ev % 400 == 0))
                return 29;
            else
                return 28;
        }
        else if (honap == 4 || honap == 6 || honap == 9 || honap == 11)
            return 30;
        else
            return 31;
    }

    Ido operator-(const Ido& t) const {
        Ido temp;
        temp.perc = perc - t.perc;
        temp.ora = ora - t.ora;
        temp.nap = nap - t.nap;
        temp.honap = honap - t.honap;
        temp.ev = ev - t.ev;

        if (temp.perc < 0) {
            temp.perc += 60;
            temp.ora--;
        }
        if (temp.ora < 0) {
            temp.ora += 24;
            temp.nap--;
        }
        if (temp.nap < 0) {
            temp.nap += getNapokAHonapban(temp.honap, temp.ev);
            temp.honap--;
        }
        if (temp.honap < 0) {
            temp.honap += 12;
            temp.ev--;
        }

        return temp;
    }
};

#endif // !IDO_H

